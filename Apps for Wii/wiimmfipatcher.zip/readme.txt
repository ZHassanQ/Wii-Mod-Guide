Instructions:

The "apps" folder you see in this archive needs to go onto your SD root. You need a Homebrew Channel installed on your Wii for this to all work.

When you copy the folders correctly to the SD card, a new application will appear in the Homebrew Channel called "Wiimmfi Patcher".

When you run it, all you must do is insert a disc and wait, and it will attempt to automatically patch your game, and then run it.

Once your game is running, simply try to connect to Nintendo WFC. If you get error codes, check https://wiimmfi.de/error to find out why. Error Code 60000 means you need a new friend code. 

Naturally, all patches are temporary, as the Wii can't write data to a disc. But it's suprising how many people think it can... So you must run this every time you wish to play on Wiimmfi.

Report problems with the app to MrBean35000vr or Leseratte.


CHANGELOG

v0.7

- Adds support for the new security updates for games other than Mario Kart Wii.
- Makes all games run under the proper IOS (if available), which should fix USB problems in certain games.
- Adds UPnP support for Mario Kart Wii (all regions), SSBB (PAL and USA) and Animal Crossing (PAL and USA).
- Fix stupid 51420 error for Mario Kart Wii.
- Fix error where some out-of-region games wouldn't start properly.
- Games that still have their official server but which currently return error code 23400
  (CoD: Black Ops, CoD: Modern Warfare Reflex, CoD: Modern Warfare 3, Rock Band 3, The Beatles: Rock Band)
  will have that error 23400 fixed (but are obviously still running over their original servers instead of Wiimmfi).
  Thanks to InvoxiPlayGames for creating these patches.
- CoD: World At War works again, using a proxy server operated by InvoxiPlayGames. 
  Note: This causes user data to be sent both to InvoxiPlayGames' server, and to the original Demonware game servers. 
  The Wiimmfi team is not responsible for anything that happens on any Call of Duty or Rock Band game servers.
- Fixes a bug where Mario Kart Wii started through this patcher wouldn't be able to set / enable
  competition downloads through WiiConnect24.
- Fixes a bug where the patcher would freeze if you inserted the game disc incorrectly (label side down). Yeah ...
- Improves the disc reading logic / code so it should hang less often with unreliable disc drives.

v0.6

- Adds support for the new Wiimmfi patching service for Mario Kart Wii.

v0.5

- Removes Gamestats skip code, it's no longer required.
- Fixes a bug where not all strings in Mario Kart Wii would correctly patch!
- Inserts a call that resets the wireless before booting. This makes it work from FlashHax.
- Removed all dependencies on files on the SD card! Other than itself, of course.

v0.4

- Animal Crossing no longer runs horrendously slow.
- Mario Strikers Charged (USA/PAL) now have an inbuilt Gamestats skip code to bypass the missing server (fix Error 98020).


v0.3

- Now a standalone app.
- Even better compatability with games.
- Super Smash Bros. Brawl no longer runs horrendously slow.


v0.2

- Changed patching method to fix the problems of v0.1.
- Improved compatability with games that aren't Mario Kart.


v0.1

- Initial version.
- Uses BrainSlug.
- Patching method not very robust yet.
